import 'package:flutter/material.dart';
import 'storage_service.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final StorageService _storageService = StorageService();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter JSON Storage',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: DataInputScreen(storageService: _storageService),
    );
  }
}

class DataInputScreen extends StatefulWidget {
  final StorageService storageService;

  DataInputScreen({required this.storageService});

  @override
  _DataInputScreenState createState() => _DataInputScreenState();
}

class _DataInputScreenState extends State<DataInputScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _cityController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Input Data'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: 'Name',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            TextField(
              controller: _ageController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Age',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            TextField(
              controller: _cityController,
              decoration: InputDecoration(
                labelText: 'City',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                // Ambil data dari controller
                String name = _nameController.text;
                String age = _ageController.text;
                String city = _cityController.text;

                // Validasi input
                if (name.isEmpty || age.isEmpty || city.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('All fields must be filled out!')),
                  );
                  return;
                }

                // Konversi data menjadi format yang bisa disimpan
                Map<String, dynamic> data = {
                  'name': name,
                  'age':
                      int.tryParse(age) ?? 0, // Default ke 0 jika parsing gagal
                  'city': city,
                };

                // Simpan data ke file
                await widget.storageService.saveData(data);

                // Beri feedback pada pengguna
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Data Saved!')),
                );

                // Hapus inputan
                _nameController.clear();
                _ageController.clear();
                _cityController.clear();
              },
              child: Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}
