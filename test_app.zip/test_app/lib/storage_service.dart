import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

class StorageService {
  Future<String> get _localPath async {
    final directory = await getApplicationDocumentsDirectory();
    return directory.path;
  }

  Future<File> get _localFile async {
    final path = await _localPath;
    return File('$path/data.json');
  }

  // Menyimpan data baru ke file JSON (mengganti data lama)
  Future<void> saveData(Map<String, dynamic> newData) async {
    final file = await _localFile;

    // Simpan data baru ke dalam file JSON
    String jsonString = json.encode(newData);
    await file.writeAsString(jsonString, mode: FileMode.writeOnly);
  }

  // Membaca data dari file JSON di direktori lokal
  Future<Map<String, dynamic>> readData() async {
    try {
      final file = await _localFile;
      String jsonString = await file.readAsString();
      return json.decode(jsonString);
    } catch (e) {
      print("Error reading local data: $e");
      return {};
    }
  }
}
